package in.mused.api.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Song.class)
public class SongDataOnDemand {
}

package in.mused.api.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = UserConnection.class)
public class UserConnectionDataOnDemand {
}

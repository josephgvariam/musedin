package in.mused.api.service;

import in.mused.api.domain.Player;
import in.mused.api.domain.Song;
import in.mused.api.domain.User;

import org.bson.types.ObjectId;
import org.springframework.roo.addon.layers.service.RooService;

@RooService(domainTypes = { in.mused.api.domain.Player.class })
public interface PlayerService {

	public Player getActivePlayer(User user);
	
	public void updatePlaylistSong(ObjectId playerId, Song song);
	public void pushPlaylistSong(ObjectId playerId, Song song);
	public void updatePlayerShallow(Player player);
	public void updateSongDetails(ObjectId playerId, Song song);
	public void destroyPlaylistSong(ObjectId playerId, ObjectId songId);
}

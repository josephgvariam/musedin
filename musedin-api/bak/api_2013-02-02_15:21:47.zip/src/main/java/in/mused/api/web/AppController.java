package in.mused.api.web;

import flexjson.JSONSerializer;
import in.mused.api.domain.Player;
import in.mused.api.domain.Song;
import in.mused.api.domain.User;
import in.mused.api.service.PlayerService;
import in.mused.api.service.SongService;
import in.mused.api.service.UserService;
import in.mused.api.util.ObjectIdTransformer;

import java.security.Principal;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AppController {
	
	Logger log = LogManager.getLogger(AppController.class);
	
	@Autowired
	UserService userService;
	
	@Autowired
	SongService songService;
	
	@Autowired
    PlayerService playerService;
	
    @RequestMapping(value = "/player", produces = "text/html")
    public String init(Model uiModel, Principal principal) {    
    	log.info("Initializing Player for user: "+principal.getName());
    	
    	User user = userService.findUserByUsername(principal.getName());
    	
    	Player player = getActivePlayer(user);
    	if(player == null){
    		player = new Player();	
    		player.setActive(true);
    		String uuid = UUID.randomUUID().toString();
    		player.setCode(uuid.substring(uuid.length()-5,uuid.length()));
    		player.setUserId(user.getId());
    		player.setPlaying(false);
    		//player.setPlaylistSongs(dummyPlaylist());
    		//playerService.savePlayer(player);
    	}
    	
    	
    	
    	uiModel.addAttribute("playerJson", player.toJson());
    	
    	JSONSerializer serializer = new JSONSerializer().transform(new ObjectIdTransformer(), org.bson.types.ObjectId.class);
        String playlistSongsJson = serializer.exclude("*.class").serialize(player.getPlaylistSongs());
    	uiModel.addAttribute("playlistSongsJson", playlistSongsJson);
    	//uiModel.addAttribute("playerIdJson", "{\"id\": \""+player.getId()+"\"}");

        return "player";
    }
    
    private Player getActivePlayer(User user){
    	//return playerService.getActivePlayer(user);
    	return null;
    }

	private Set<Song> dummyPlaylist() {
		Set<Song> playlist = new HashSet<Song>();
		
		Song s1 = new Song();
		s1.setTitle("Metallica - One");
		s1.setSongUrl("/");
		s1.setAlbum("");
		s1.setArtist("");
		s1.setComment("");
		s1.setGenre("");
		s1.setIconUrl("");
		s1.setYear("");
		s1.setId(ObjectId.get());
		//songService.saveSong(s1);
		playlist.add(s1);

		Song s2 = new Song();
		s2.setTitle("Metallica - Two");
		s2.setSongUrl("/");
		s2.setAlbum("");
		s2.setArtist("");
		s2.setComment("");
		s2.setGenre("");
		s2.setIconUrl("");
		s2.setYear("");
		s2.setId(ObjectId.get());
		//songService.saveSong(s2);
		playlist.add(s2);
		
		Song s3 = new Song();
		s3.setTitle("Metallica - Three");
		s3.setSongUrl("/");
		s3.setAlbum("");
		s3.setArtist("");
		s3.setComment("");
		s3.setGenre("");
		s3.setIconUrl("");
		s3.setYear("");
		s3.setId(ObjectId.get());
		//songService.saveSong(s3);
		playlist.add(s3);
		
		return playlist;
	}
}

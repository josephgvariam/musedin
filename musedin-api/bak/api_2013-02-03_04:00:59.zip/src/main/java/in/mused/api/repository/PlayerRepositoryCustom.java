package in.mused.api.repository;

import in.mused.api.domain.Player;
import in.mused.api.domain.Song;

import org.bson.types.ObjectId;

public interface PlayerRepositoryCustom {
	public void pushPlaylistSong(ObjectId playerId, Song song);
	public void updatePlaylistSong(ObjectId playerId, Song song);
	public void updatePlayerShallow(Player player);
	public void destroyPlaylistSong(ObjectId playerId, ObjectId songId);
}

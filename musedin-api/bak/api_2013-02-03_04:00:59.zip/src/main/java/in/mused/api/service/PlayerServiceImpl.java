package in.mused.api.service;

import java.net.URI;
import java.util.ArrayList;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.bson.types.ObjectId;
import org.springframework.scheduling.annotation.Async;

import flexjson.JSONDeserializer;

import in.mused.api.domain.Player;
import in.mused.api.domain.Song;
import in.mused.api.domain.User;


public class PlayerServiceImpl implements PlayerService {
	
	Logger log = LogManager.getLogger(PlayerServiceImpl.class);
	
	@Override
	public Player getActivePlayer(User user) {		
		return playerRepository.findByUserIdAndActive(user.getId(), true);		
	}
	
	
	public void updatePlaylistSong(ObjectId playerId, Song song){
		playerRepository.updatePlaylistSong(playerId, song);
	}
	
	public void pushPlaylistSong(ObjectId playerId, Song song){
		playerRepository.pushPlaylistSong(playerId, song);
	}
	
	public void updatePlayerShallow(Player player){
		playerRepository.updatePlayerShallow(player);
	}
	
	public void destroyPlaylistSong(ObjectId playerId, ObjectId songId){
		playerRepository.destroyPlaylistSong(playerId, songId);
	}
	
	@Async
	public void updateSongDetails(ObjectId playerId, Song song){		
		try {	
			String title = sanitize(song.getTitle());
			
			HttpClient httpClient = new DefaultHttpClient();
			URIBuilder builder = new URIBuilder();
			builder.setScheme("http").setHost("itunes.apple.com/").setPath("/search")
			    .setParameter("term", title)
			    .setParameter("entity", "song")
			    .setParameter("limit", "1")
			    .setParameter("media", "music");
			URI uri = builder.build();
			HttpGet httpget = new HttpGet(uri);
			
			HttpResponse response = httpClient.execute(httpget);
			
			if (response.getStatusLine().getStatusCode() != 200) {
				log.error("Unable to retrieve song details: "+title);				
				song.setTitle(song.getTitle().replaceAll("\\.mp3", ""));
			}
			else{
				String json = EntityUtils.toString(response.getEntity());

				Map<String, Object> map = new JSONDeserializer<Map<String,Object>>().deserialize(json);
				if(((ArrayList)map.get("results")).size()>0){
					log.info("Got song details: "+title);
					Map<String,String> vmap = (Map<String, String>) ((ArrayList)map.get("results")).get(0);
					
					if(vmap.containsKey("artworkUrl100")) {
						song.setIconUrl(vmap.get("artworkUrl100"));
					}
					
					if(vmap.containsKey("trackName")){
						song.setTitle(vmap.get("trackName"));
					}else{
						if(vmap.containsKey("trackCensoredName")){
							song.setTitle(vmap.get("trackCensoredName"));
						}	
					}
					
					if(vmap.containsKey("collectionName")) {
						song.setAlbum(vmap.get("collectionName"));
					}else{
						if(vmap.containsKey("collectionCensoredName")) {
							song.setAlbum(vmap.get("collectionCensoredName"));
						}
					}
					
					if(vmap.containsKey("artistName")) song.setArtist(vmap.get("artistName"));					
					if(vmap.containsKey("primaryGenreName")) song.setGenre(vmap.get("primaryGenreName"));
				}else{
					log.info("No song details available: "+title);
					song.setTitle(song.getTitle().replaceAll("\\.mp3", ""));
				}
			}
			

			
			
		} catch (Exception e) {
			log.error("Unable to retrieve song details!",e);
		}
		
		updatePlaylistSong(playerId, song);

	}
	
	private String sanitize(String s){
		String x = s.replaceAll("\\.mp3", "");
		x = x.replaceAll("[^A-Za-z0-9 ]", "");
		return x;
		
	}
}

package in.mused.api.service;

import org.springframework.roo.addon.layers.service.RooService;

@RooService(domainTypes = { in.mused.api.domain.UserConnection.class })
public interface UserConnectionService {
}

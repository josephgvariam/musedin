package in.mused.api.repository;

import in.mused.api.domain.Player;
import in.mused.api.domain.Song;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Update.update;
import static org.springframework.data.mongodb.core.query.Query.query;

public class PlayerRepositoryImpl implements PlayerRepositoryCustom {

	@Autowired
    protected MongoTemplate mongoTemplate;
	
	public void pushPlaylistSong(ObjectId playerId, Song song){
		Update u = new Update()
			.push("playlistSongs", song);
			
		mongoTemplate.updateFirst(query(where("id").is(playerId)), u, Player.class);
	}
	
	public void updatePlaylistSong(ObjectId playerId, Song song){
		Update u = update("playlistSongs.$.title", song.getTitle())
				.set("playlistSongs.$.artist", song.getArtist())
				.set("playlistSongs.$.album", song.getAlbum())
				.set("playlistSongs.$.year", song.getYear())
				.set("playlistSongs.$.genre", song.getGenre())
				.set("playlistSongs.$.comment", song.getComment())
				.set("playlistSongs.$.iconUrl", song.getIconUrl())
				.set("playlistSongs.$.upVotes", song.getUpVotes()) //use .inc in an other method
				.set("playlistSongs.$.downVotes", song.getDownVotes()); //use .inc
		
		mongoTemplate.updateFirst(query(where("id").is(playerId).and("playlistSongs.id").is(song.getId())), u, Player.class);
	}
	
	public void updatePlayerShallow(Player player){
		Update u = update("code", player.getCode())
				.set("active", player.isActive())
				.set("userId", player.getUserId())
				.set("nowPlayingSong", player.getNowPlayingSong())
				.set("playing", player.isPlaying());
				
		mongoTemplate.updateFirst(query(where("id").is(player.getId())), u, Player.class);
	}
	
	public void destroyPlaylistSong(ObjectId playerId, ObjectId songId){
		Song song = new Song();
		song.setId(songId);
		Update u = new Update()
		.pull("playlistSongs", song);
		mongoTemplate.updateFirst(query(where("id").is(playerId).and("playlistSongs.id").is(songId)), u, Player.class);
	}

}

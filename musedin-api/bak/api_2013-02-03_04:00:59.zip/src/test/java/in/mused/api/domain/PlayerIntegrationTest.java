package in.mused.api.domain;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Player.class, transactional = false)
public class PlayerIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}

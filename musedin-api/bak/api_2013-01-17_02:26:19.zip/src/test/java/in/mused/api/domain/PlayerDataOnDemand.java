package in.mused.api.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Player.class)
public class PlayerDataOnDemand {
}

package in.mused.api.domain;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = UserConnection.class, transactional = false)
public class UserConnectionIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}

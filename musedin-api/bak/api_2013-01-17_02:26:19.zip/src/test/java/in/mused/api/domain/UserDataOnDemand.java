package in.mused.api.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = User.class)
public class UserDataOnDemand {
}

package in.mused.api.domain;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Library.class, transactional = false)
public class LibraryIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}

package in.mused.api.service;

import org.springframework.roo.addon.layers.service.RooService;

@RooService(domainTypes = { in.mused.api.domain.Player.class })
public interface PlayerService {
}

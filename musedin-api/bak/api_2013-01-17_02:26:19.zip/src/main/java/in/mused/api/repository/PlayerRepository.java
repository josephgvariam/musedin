package in.mused.api.repository;

import in.mused.api.domain.Player;
import java.util.List;
import org.springframework.roo.addon.layers.repository.mongo.RooMongoRepository;

@RooMongoRepository(domainType = Player.class)
public interface PlayerRepository {

    List<in.mused.api.domain.Player> findAll();
}

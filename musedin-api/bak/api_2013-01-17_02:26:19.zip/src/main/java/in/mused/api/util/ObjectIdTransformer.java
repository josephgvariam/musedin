package in.mused.api.util;

import flexjson.transformer.AbstractTransformer;


public class ObjectIdTransformer extends AbstractTransformer {

    public void transform(Object object) {
        getContext().writeQuoted(object.toString());
    }

}

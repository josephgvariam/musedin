package in.mused.api.domain;

import javax.validation.constraints.NotNull;
import org.bson.types.ObjectId;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.layers.repository.mongo.RooMongoEntity;
import org.springframework.roo.addon.tostring.RooToString;

@RooJavaBean
@RooToString
@RooMongoEntity(identifierType = ObjectId.class)
public class Song {

    @NotNull
    private String title;

    private String artist;

    private String album;

    private String year;

    private String genre;

    private String comment;

    private String iconUrl;

    private int upVotes;

    private int downVotes;

    @NotNull
    private String url;
}

package in.mused.api.web;

import in.mused.api.domain.Player;
import in.mused.api.service.SecurityService;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.roo.addon.web.mvc.controller.json.RooWebJson;
import org.springframework.roo.addon.web.mvc.controller.scaffold.RooWebScaffold;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@RequestMapping(value={"/players","/api/players"})
@Controller
@RooWebScaffold(path = "players", formBackingObject = Player.class)
@RooWebJson(jsonObject = Player.class)
public class PlayerController {
	
	Logger log = LogManager.getLogger(PlayerController.class);
	
	@Autowired
	SecurityService securityService;
	
    @RequestMapping(value = "/test", headers = "Accept=application/json")
    @ResponseBody
    public ResponseEntity<String> test() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Type", "application/json; charset=utf-8");
        String passwd = securityService.encodePassword("joppu@variam.com", "musedin", "admin");
        ResponseEntity<String> re = new ResponseEntity<String>(passwd, headers, HttpStatus.OK);
        return re;
    }
    

}

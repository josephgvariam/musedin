package in.mused.api.security;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.web.util.RequestMatcher;

public class MusedinRequestMatcher implements RequestMatcher {

	@Override
	public boolean matches(HttpServletRequest request) {
		// TODO Auto-generated method stub
		return false;
	}

}

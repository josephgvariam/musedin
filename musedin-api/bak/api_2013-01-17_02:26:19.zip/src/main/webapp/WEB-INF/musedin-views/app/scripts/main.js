var app = new Backbone.Marionette.Application();

app.addRegions({
  playerRegion: '#player',
  playlistRegion: '#playlist',
  libraryRegion: '#library'
});


var Song = Backbone.RelationalModel.extend({
    urlRoot: '/songs'
});

var SongCollection = Backbone.Collection.extend({
    model: Song,
    url: function( models ) {
    	console.debug('/animal/' + ( models ? 'set/' + _.pluck( models, 'id' ).join(';') + '/' : '' ));
        return '/animal/' + ( models ? 'set/' + _.pluck( models, 'id' ).join(';') + '/' : '' );
    }
});

var Player = Backbone.RelationalModel.extend({
    urlRoot: '/players',
    relations: [{
      type: Backbone.HasMany,
      key: 'playlist',
      relatedModel: 'Song',
      includeInJSON: true,
      collectionType: 'SongCollection'
    }]
});

var PlayerView = Backbone.Marionette.ItemView.extend({
  template: "#template-player"
});

var PlaylistView = Backbone.Marionette.ItemView.extend({
  template: "#template-playlist"
});

var LibraryView = Backbone.Marionette.ItemView.extend({
  template: "#template-library"
});

app.addInitializer(function(options){
  
  var playerView = new PlayerView();
  var playlistView = new PlaylistView();
  var libraryView = new LibraryView();
      
  app.playerRegion.show(playerView);
  app.playlistRegion.show(playlistView);
  app.libraryRegion.show(libraryView);
});

var Router = Backbone.Marionette.AppRouter.extend({
  appRoutes: {
    '*filter': 'setFilter'
  },
  controller: {
    setFilter: function(param) {
      app.vent.trigger('todoList:filter', param.trim() || '');
    }
  }
});

$(function() {
  app.start();
  new Router();
  Backbone.history.start();
});